﻿using System;

namespace AssetWorks.UI.Core.Integrations
{
    /// <summary>
    /// TestResults contains methods to push test execution results in test rail
    /// </summary>
    public class TestResults
    {
        private string _testTitle;
        private string _testResult;
        private string _error;

        /// <summary>
        /// TestResults : set properties for test results
        /// </summary>
        /// <param name="Title"></param>
        /// <param name="Result"></param>
        /// <param name="ErrorMessage"></param>
        public TestResults(string Title, string Result, string ErrorMessage)
        {
            _testTitle = Title;
            _testResult = Result;
            _error = ErrorMessage;
        }

        /// <summary>
        /// get set test title
        /// </summary>
        public string TestTitle
        {
            get { return _testTitle; }
            set { _testTitle = value; }
        }

        /// <summary>
        /// get set test result
        /// </summary>
        public string TestResult
        {
            get { return _testResult; }
            set { _testResult = value; }
        }

        /// <summary>
        /// get set test error
        /// </summary>
        public string Error
        {
            get { return _error; }
            set { _error = value; }
        }
    }
}
