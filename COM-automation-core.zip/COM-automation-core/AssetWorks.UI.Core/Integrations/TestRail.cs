﻿using System;
using System.Text;
using System.Net.Http;
using Newtonsoft.Json;
using System.Collections;
using Newtonsoft.Json.Linq;
using System.Net.Http.Headers;
using AssetWorks.UI.Core.Utils;
using System.Collections.Generic;

namespace AssetWorks.UI.Core.Integrations
{
    /// <summary>
    /// TestRail class contains the integration of test execution results in TestRail test cases
    /// </summary>
    public class TestRail
    {

        /// <summary>
        /// GetRequestClient : create client for test rail
        /// </summary>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public HttpClient GetRequestClient()
        {
            HttpClient client = new HttpClient();
            try
            {
                string url = AppSettings.ApiBaseUrl;
                client.BaseAddress = new Uri(url);
                client.DefaultRequestHeaders.Accept
                    .Add(new MediaTypeWithQualityHeaderValue("application/json"));

                client.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue(
                        "Basic", Convert.ToBase64String(
                            ASCIIEncoding.ASCII.GetBytes($"{AppSettings.ApiUsername}:{AppSettings.ApiPassword}")));
            }
            catch (Exception ex)
            {
                AppSettings.CoreLogger.Error($"{ex.Message}");
                AppSettings.CoreLogger.Error($"{ex.StackTrace}");
                throw new Exception(ex.Message);
            }
            return client;
        }

        /// <summary>
        /// GetRunDetails : create data for run details
        /// </summary>
        /// <returns></returns>
        private JObject GetRunDetails()
        {
            JObject jsonParams = new JObject();
            jsonParams = JObject.FromObject(new
            {
                name = "Auto run " + DateTime.UtcNow.ToString(),
                description = "Automatic test run created on " + DateTime.UtcNow.ToString(),
                milestone_id = AppSettings.ApiMilestoneId,
                include_all = true,
                refs = "Automation scripts"
            });
            return jsonParams;
        }

        /// <summary>
        /// AddRunAndGetRunId : This function create a new test run and return run id
        /// </summary>
        /// <returns>run id</returns>
        /// <exception cref="Exception"></exception>        
        public int AddRunAndGetRunId()
        {
            int _runid = 0;
            try
            {
                HttpClient client = GetRequestClient();
                string apiUrl = AppSettings.ApiEndPoint + "add_run/" + AppSettings.ApiProjectId;
                JObject data = GetRunDetails();
                var content = new StringContent(data.ToString(), Encoding.UTF8, "application/json");
                HttpResponseMessage response = client.PostAsync(apiUrl, content).Result;
                if (response.IsSuccessStatusCode)
                {
                    // Parse the response body.
                    var dataObjects = response.Content.ReadAsStringAsync().Result;
                    var SteamDetails = JsonConvert.DeserializeObject<dynamic>(dataObjects);
                    _runid = SteamDetails["id"];
                }
                else
                {
                    throw new Exception("Testrail error : " + response.RequestMessage);
                }
            }
            catch (Exception ex)
            {
                AppSettings.CoreLogger.Error($"{ex.Message}");
                AppSettings.CoreLogger.Error($"{ex.StackTrace}");
                throw new Exception(ex.Message);
            }

            return _runid;
        }

        /// <summary>
        /// UpdateTestResultsToTestRail : This function updates test results of particular test run
        /// </summary>
        /// <param name="runId"></param>
        /// <param name="testResults"></param>
        /// <exception cref="Exception"></exception>
        public void UpdateTestResultsToTestRail(int runId, List<TestResults> testResults)
        {
            string testRailRunId = runId.ToString();
            HttpClient client = GetRequestClient();

            IDictionary<string, string> testcaseDeatilsInTestRail = new Dictionary<string, string>();
            testcaseDeatilsInTestRail = GetTestsByTestRunId(testRailRunId);

            // bulk-add multiple test results to test rail
            ArrayList newresult = new ArrayList();
            foreach (var testResult in testResults)
            {
                foreach (var test in testcaseDeatilsInTestRail)
                {
                    // Test Title is mapping field between UI automation ans Test Rail. We are checking if Titles are matching, then update the result back to test rail.                    
                    if (testResult.TestTitle == test.Key)   // E.g if("Login_With_Valid_Use" == "Login_With_Valid_Use")
                    {
                        var tempData = new Dictionary<string, object>
                        {
                            { "case_id", test.Value },
                            { "status_id", GetStatusIdFromCode(testResult.TestResult) },
                            { "comment", testResult.Error}
                        };
                        newresult.Add(tempData);
                    }
                }
            }

            var data = new Dictionary<string, object>
            {
                { "results", newresult }
            };
            var jsonString = JsonConvert.SerializeObject(data);
            JObject jsonParams = JObject.Parse(jsonString);
            var content = new StringContent(jsonParams.ToString(), Encoding.UTF8, "application/json");
            string apiUrl = AppSettings.ApiEndPoint + "add_results_for_cases/" + testRailRunId;
            try
            {
                HttpResponseMessage response = client.PostAsync(apiUrl, content).Result;
                if (response.IsSuccessStatusCode)
                {
                    // Parse the response body.
                    var dataObjects = response.Content.ReadAsStringAsync().Result;
                    var SteamDetails = JsonConvert.DeserializeObject<dynamic>(dataObjects);

                }
                else
                {
                    throw new Exception("Testrail error : " + response.RequestMessage);
                }
            }
            catch (Exception ex)
            {
                AppSettings.CoreLogger.Error($"{ex.Message}");
                AppSettings.CoreLogger.Error($"{ex.StackTrace}");
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// GetTestsByTestRunId : This function gets test details of particular test run
        /// </summary>
        /// <param name="TestRunId"></param>
        /// <returns> test case details</returns>
        private IDictionary<string, string> GetTestsByTestRunId(string TestRunId)
        {
            HttpClient client = GetRequestClient();
            IDictionary<string, string> testcaseDeatilsInTestRail = new Dictionary<string, string>();
            string apiUrl = AppSettings.ApiEndPoint + "get_tests/" + TestRunId;
            HttpResponseMessage response = client.GetAsync(apiUrl).Result;
            var dataObjects = response.Content.ReadAsStringAsync().Result;
            var SteamDetails = JsonConvert.DeserializeObject<dynamic>(dataObjects)["tests"];

            foreach (var test in SteamDetails)
            {
                testcaseDeatilsInTestRail.Add((string)test["title"], (string)test["case_id"]);
            }
            return testcaseDeatilsInTestRail;
        }

        /// <summary>
        /// GetStatusIdFromCode : This function gets equivalent status Id from status code
        /// </summary>
        /// <param name="StatusCode"></param>
        /// <returns></returns>        
        private static string GetStatusIdFromCode(string StatusCode)
        {
            string statusId = null;

            switch (StatusCode)
            {
                case "Passed":
                    statusId = "1";
                    break;
                case "Failed":
                    statusId = "5";
                    break;
                case "Timeout":
                    statusId = "5";
                    break;
                case "Aborted":
                    statusId = "4";
                    break;
                default:
                    Console.WriteLine("Not Valid Status Code");
                    break;
            }

            return statusId;
        }

    }
}
