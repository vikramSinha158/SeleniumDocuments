﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AssetWorks.UI.Core.Utils;
using AventStack.ExtentReports;
using AventStack.ExtentReports.Reporter;
using AventStack.ExtentReports.Reporter.Configuration;
using NUnit.Framework;
using NUnit.Framework.Interfaces;
using OpenQA.Selenium;

namespace AssetWorks.UI.Core.Reporting
{
    /// <summary>
    /// Initilizes extent report instance for reporting
    /// </summary>
    public class ExtentReport
    {
        [ThreadStatic]
        public static ExtentReports Extent;
        [ThreadStatic]
        public static ExtentTest Test;
        public ExtentReports Report;
        public static ExtentHtmlReporter HtmlReporter;
        public static String TC_Name;

        /// <summary>
        /// Configuring teh extent report
        /// </summary>
        public static void SetupExtentreport()
        {
            if (AppSettings.ExtentReport)
            {
                AppSettings.CoreLogger.Info($"Initializing Extent Report instance");
                var reportPath = new CommonUtils().GetFolderPath("Reports") + "Index.html";

                if (HtmlReporter == null)
                    HtmlReporter = new ExtentHtmlReporter(reportPath);

                HtmlReporter.Config.Theme = Theme.Dark;
                HtmlReporter.Config.DocumentTitle = "ExtentReport";
                HtmlReporter.Config.ReportName = "AssetWorksReport";

                if (Extent == null)
                    Extent = new ExtentReports();

                Extent.AttachReporter(HtmlReporter);
                AppSettings.CoreLogger.Info($"Extent report created at '{reportPath}'");
            }
        }

        /// <summary>
        /// Flush Extent Report
        /// </summary>
        public static void FlushExtentReport()
        {
            if (AppSettings.ExtentReport)
                Extent.Flush();
        }

        /// <summary>
        /// Get test case Name
        /// </summary>
        /// <param name="ContextName"></param>
        public static void CreateTest(string ContextName)
        {
            if (AppSettings.ExtentReport)
            {
                TC_Name = ContextName;
                Test = Extent.CreateTest(ContextName);
            }
        }

        /// <summary>
        /// Inserting the log in the report
        /// </summary>
        /// <param name="Driver"></param>
        public static void StoreResults(IWebDriver Driver)
        {
            if (AppSettings.ExtentReport)
            {
                bool passed = TestContext.CurrentContext.Result.Outcome.Status == NUnit.Framework.Interfaces.TestStatus.Passed;
                var exec_status = TestContext.CurrentContext.Result.Outcome.Status;
                var stacktrace = string.IsNullOrEmpty(TestContext.CurrentContext.Result.StackTrace) ? ""
                : string.Format("{0}", TestContext.CurrentContext.Result.StackTrace);
                Status logstatus = Status.Pass;
                String screenShotPath = CreateFolder("ScreenShot");
                string fileName;
                MediaEntityModelProvider mediaEntity;

                DateTime time = DateTime.Now;
                fileName = "Screenshot_" + time.ToString("h_mm_ss") + TC_Name + ".png";

                switch (exec_status)
                {
                    case TestStatus.Failed:
                        logstatus = Status.Fail;
                        mediaEntity = CommonUtils.TakeScreenshot(Driver, screenShotPath);
                        Test.Log(Status.Fail, "Fail");
                        Test.Fail("ExtentReport 4 Capture: Test Failed", mediaEntity);
                        Test.Log(Status.Fail, "Traditional Snapshot below: " + Test.AddScreenCaptureFromPath("Screenshots\\" + fileName));
                        break;
                    case TestStatus.Passed:
                        logstatus = Status.Pass;
                        mediaEntity = CommonUtils.TakeScreenshot(Driver, screenShotPath);
                        Test.Log(Status.Pass, "Pass");
                        Test.Pass("ExtentReport 4 Capture: Test Passed", mediaEntity);
                        Test.Log(Status.Pass, "Traditional Snapshot below: " + Test.AddScreenCaptureFromPath("Screenshots\\" + fileName));
                        break;
                    case TestStatus.Inconclusive:
                        logstatus = Status.Warning;
                        break;
                    case TestStatus.Skipped:
                        logstatus = Status.Skip;
                        break;
                    default:
                        break;
                }
                Test.Log(logstatus, "Test: " + TC_Name + " Status:" + logstatus + stacktrace);
            }
        }

        /// <summary>
        /// Creating extent report folder
        /// </summary>
        /// <param name="FolderName"></param>
        /// <returns></returns>
        private static string CreateFolder(string FolderName)
        {
            var solutionPath = new CommonUtils().SolutionPath();
            var parentSolutionPath = Directory.GetParent(solutionPath).FullName + $"\\{FolderName}";

            if (!Directory.Exists(parentSolutionPath))
                Directory.CreateDirectory(parentSolutionPath);

            AppSettings.CoreLogger.Info($"ScreenShot folder created at '{parentSolutionPath}'");
            return parentSolutionPath;
        }
    }
}
