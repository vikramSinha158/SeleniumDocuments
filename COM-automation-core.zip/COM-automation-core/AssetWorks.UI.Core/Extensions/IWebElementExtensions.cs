﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AssetWorks.UI.Core.Base;
using AssetWorks.UI.Core.Utils;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;

namespace AssetWorks.UI.Core.Extensions
{
    /// <summary>
    /// IWebElementExtensions class contains all common element operations
    /// </summary>
    public static class IWebElementExtensions
    {
        /// <summary>This method selects the random value from dropdown .</summary>
        /// <param name="WebElement">WebElement on which this operation is to be performed.</param>
        /// <returns>Selected value as string for reference later.</returns>

        public static string SelectRandomValuefromDropdown(this IWebElement WebElement, int startIndex = 0, bool excludeCurrentValue = true)
        {
            SelectElement selectElement = new SelectElement(WebElement);
            int randomValue = 0;
            int count = 0;

            if (selectElement.Options.Count == 0)
            {
                return null;
            }

            Random random = new Random();

            if (excludeCurrentValue && selectElement.Options.Count > 1)
            {
                var currentValue = WebElement.GetVisibleText();
                var allValue = WebElement.GetDropdownValueList();
                var currentIndex = allValue.IndexOf(currentValue);

                do
                {
                    randomValue = random.Next(startIndex, selectElement.Options.Count);
                    count++;
                } while (randomValue == currentIndex && count < 10);
            }
            selectElement.SelectByIndex(randomValue);
            var value = selectElement.SelectedOption.Text.ToString().Trim();
            AppSettings.CoreLogger.Info($"Selecting random value in drop down as '{value}'");
            return value;
        }

        /// <summary>This method gets the dropdown value list.</summary>
        /// <param name="WebElement">WebElement on which this operation is to be performed.</param>
        /// <returns>List of values in a dropdown</returns>
        public static List<string> GetDropdownValueList(this IWebElement WebElement)
        {
            SelectElement element = new SelectElement(WebElement);
            if (element.Options.Count == 0) return null; //if there are no elements in dropdown, return null
            List<string> valueList = new List<string>();
            foreach (var option in element.Options)
            {
                valueList.Add(option.Text.Trim());
                AppSettings.CoreLogger.Info($"Getting drop down list value as '{option.Text.Trim()}'");
            }
            return valueList;
        }

        /// <summary>This method gets the dropdown list total count.</summary>
        /// <param name="WebElement">WebElement on which this operation is to be performed.</param>
        /// <returns>List count as integer.</returns>
        public static int GetDropdownListTotalCount(this IWebElement WebElement)
        {
            SelectElement element = new SelectElement(WebElement);
            var value = element.Options.Count;
            AppSettings.CoreLogger.Info($"Getting drop down list value count as '{value}'");
            return value;
        }

        /// <summary>This method clicks the drop down value by containing text.</summary>
        /// <param name="WebElement">WebElement on which this operation is to be performed.</param>
        /// <param name="text">Text for which dropdown value is to be searched.</param>
        /// <returns>Boolean value for success or failure of the method.if value is found, it will return true otherwise false.</returns>
        public static bool ClickDropDownValuebyContainingText(this IWebElement WebElement, string text)
        {            
            bool counter = false;
            if (!string.IsNullOrWhiteSpace(text))
            {
                var itemText = text.Trim();
                SelectElement element = new SelectElement(WebElement);
                AppSettings.CoreLogger.Info($"Clicking on drop down option containing text '{text}'");
                foreach (var option in element.Options)
                {
                    if (option.Text.Trim().Contains(itemText))
                    {
                        option.Click();
                        counter = true;
                        break;
                    }
                }
            }   
            return counter;
        }

        /// <summary>This method gets the value by Index for a dropdown.</summary>
        /// <param name="WebElement">WebElement on which this operation is to be performed.</param>
        /// <param name="Index">The index whose corresponding value is to be read.</param>
        /// <returns>Selected Value as string.</returns>
        public static string GetValuedropdownByIndex(this IWebElement WebElement, int Index)
        {
            SelectElement element = new SelectElement(WebElement);
            element.SelectByIndex(Index);
            string value = element.SelectedOption.Text.ToString().Trim();
            AppSettings.CoreLogger.Info($"Getting drop down list value by index {Index} as '{value}'");
            return value;
        }

        /// <summary>This method return current selected option text of dropdown.</summary>
        /// <param name="WebElement">WebElement on which this operation is to be performed.</param>
        /// <returns>Visible Value as string.</returns>
        public static string GetVisibleText(this IWebElement WebElement)
        {
            SelectElement element = new SelectElement(WebElement);
            var value = element.SelectedOption.Text.ToString().Trim();
            AppSettings.CoreLogger.Info($"Getting visible text as '{value}'");
            return value;
        }

        /// <summary>This method verifies whether the element is displayed.</summary>
        /// <param name="WebElement">WebElement on which this operation is to be performed.</param>
        ///<returns>True if element is displayed,otherwise false.</returns>
        public static bool VerifyElementDisplay(this IWebElement WebElement, string elementName)
        {
            try
            {
                var value = BasePage.WaitUntilDisplayed(WebElement, elementName);
                AppSettings.CoreLogger.Info($"Element {elementName} is displaying");
                return value;
            }
            catch (NoSuchElementException)
            {
                AppSettings.CoreLogger.Info($"Element {elementName} not displayed");
                return false;
            }
        }

        /// <summary>This method gets the color of the css values like background.</summary>
        /// <param name="WebElement">WebElement on which this operation is to be performed.</param>
        /// <param name="CssValue">The CSS value whose color is to be fetched.</param>
        /// <returns>Color in Hex format.</returns>
        public static string GetColor(this IWebElement WebElement, string CssValue)
        {
            var value = WebElement.GetCssValue(CssValue);
            string[] colours = value.Replace("rgba(", "").Replace(")", "").Split(",");
            int r = int.Parse(colours[0]);
            int g = int.Parse(colours[1]);
            int b = int.Parse(colours[2]);
            int a = int.Parse(colours[3]);
            Color myColor = Color.FromArgb(a, r, g, b);
            string hex = "#" + myColor.R.ToString("X") + myColor.G.ToString("X") + myColor.B.ToString("X");
            string hexlower = hex.ToLower();
            AppSettings.CoreLogger.Info($"Getting color hex value as '{hexlower}'");
            return hexlower;
        }

        /// <summary>This method selects the filter value having equal value.</summary>
        /// <param name="WebElement">WebElement on which this operation is to be performed.</param>
        /// <param name="Text">The value which is to be selected from dropdown.</param>
        public static void SelectFilterValueHavingEqualValue(this IWebElement WebElement, string Text)
        {          
            if (!string.IsNullOrWhiteSpace(Text))
            {
                 SelectElement element = new SelectElement(WebElement);
                 AppSettings.CoreLogger.Info($"Selecting value having text as '{Text}'");
                 foreach (var option in element.Options)
                 {
                      if (option.Text.Trim().Equals(Text))
                      {
                      option.Click();
                      }
                 }
            }
        }

        /// <summary>This method selects the dropdown value using value attribute</summary>
        /// <param name="WebElement">WebElement on which this operation is to be performed.</param>
        /// <param name="Text">The value which is to be selected using value attribute.</param>
        public static void SelectDropdownUsingValue(this IWebElement WebElement,string ElementName,string Text)
        {
            if (!string.IsNullOrWhiteSpace(Text))
            {                
                SelectElement element = new SelectElement(WebElement);
                element.SelectByValue(Text);
                AppSettings.CoreLogger.Info($"Selected  {ElementName} having value attribute as '{Text}'");
            }
        }

        /// <summary>This Method gets the count of the rows in a web table.</summary>
        /// <param name="TableRows">WebElement for table rows.</param>
        /// <returns>Total count of the rows.</returns>
        public static int GetTotalRowsWebTable(this IList<IWebElement> TableRows)
        {
            int TotalRows = TableRows.Count;
            AppSettings.CoreLogger.Info($"Getting total rows in table as '{TotalRows}'");
            return TotalRows;
        }

        /// <summary>This method gets the count of columns in the each row of web table.</summary>
        /// <param name="TableRows">WebElement for table rows.</param>
        /// <param name="ColumnLocator">The column locator.</param>
        public static int[] GetColumnEachRow(this IList<IWebElement> TableRows, By ColumnLocator)
        {
            int[] ColumnCountEachrow = new int[TableRows.Count];
            int i = 0;
            foreach (IWebElement row in TableRows)
            {
                IList<IWebElement> ColumnsinRow = row.FindElements(ColumnLocator);
                ColumnCountEachrow[i] = ColumnsinRow.Count;
                i++;
                AppSettings.CoreLogger.Info($"Getting total columns as '{ColumnCountEachrow[i]}' in row number '{i + 1}'");
            }
            return ColumnCountEachrow;
        }

        /// <summary>This method gets the count of columns in the desired row of web table.</summary>
        /// <param name="TableRows">WebElement for table rows.</param>
        /// <param name="ColumnLocator">The column locator.</param>
        /// <param name="RowNumber">The row number whose columns are to be counted.</param>
        /// <returns>Column Count of desired row.</returns>
        public static int GetColumnCountInRow(this IList<IWebElement> TableRows, By ColumnLocator, int RowNumber)
        {
            int ColumnCountInRow = 0;
            int TotalRows = TableRows.Count;
            for (int r = 0; r <= TotalRows; r++)
            {
                if (r + 1 == RowNumber)
                {
                    IList<IWebElement> ColumnsinRow = TableRows[r].FindElements(ColumnLocator);
                    ColumnCountInRow = ColumnsinRow.Count;
                }
            }
            AppSettings.CoreLogger.Info($"Getting total columns as '{ColumnCountInRow}' in row number '{RowNumber}'");
            return ColumnCountInRow;
        }

        /// <summary>This method gets the values of desired row in web table.</summary>
        /// <param name="TableRows">WebElement for table rows.</param>
        /// <param name="ColumnLocator">The column locator.</param>
        /// <param name="RowNumber">Row number whose Values are required.</param>
        /// <returns>Values of All the columns of the row.</returns>
        public static List<string> GetRowValues(this IList<IWebElement> TableRows, By ColumnLocator, int RowNumber)
        {
            List<string> columntext = new List<string>();
            int TotalRows = TableRows.Count;
            for (int r = 0; r <= TotalRows; r++)
            {
                if (r + 1 == RowNumber)
                {
                    IList<IWebElement> ColumnsforCurrentRow = TableRows[r].FindElements(ColumnLocator);
                    foreach (IWebElement ColumnValue in ColumnsforCurrentRow)
                    {
                        columntext.Add(ColumnValue.Text);
                        AppSettings.CoreLogger.Info($"Getting row value as '{ColumnValue.Text}' in row number '{RowNumber}'");
                    }
                }
            }
            return columntext;
        }

        /// <summary>This method clicks the desired row in web table.</summary>
        /// <param name="TableRows">WebElement for table rows.</param>
        /// <param name="RowNumber">Number of the row to be clicked.</param>
        public static void ClickRow(this IList<IWebElement> TableRows, int RowNumber)
        {
            int TotalRows = TableRows.Count;
            for (int r = 0; r <= TotalRows; r++)
            {
                if (r + 1 == RowNumber)
                {
                    TableRows[r].Click();
                }
            }
            AppSettings.CoreLogger.Info($"Clicking on row number '{RowNumber}'");
        }

        /// <summary>This method gets the header of table columns in web table.</summary>
        /// <param name="HeaderCoulmns">The WebElement for header coulmns.</param>
        /// <returns>Column Headers/Title/Lable.</returns>
        public static List<string> GetTableColumnName(this IList<IWebElement> HeaderCoulmns)
        {
            List<string> Headers = HeaderCoulmns.Select(Colum => Colum.Text).ToList<string>();
            foreach (var Header in Headers)
                AppSettings.CoreLogger.Info($"Getting table header value as '{Header}'");
            return Headers;
        }


        /// <summary>This method gets the cell value in web table.</summary>
        /// <param name="TableRows">The WebElement for table rows.</param>
        /// <param name="ColumnLocator">The column locator.</param>
        /// <param name="RowNumber">Number of the row which has required cell.</param>
        /// <param name="ColumnNumber">Number of the column which has required cell.</param>
        /// <returns>Value present in cell.</returns>
        public static string GetCellValue(this IList<IWebElement> TableRows, By ColumnLocator, int RowNumber, int ColumnNumber)
        {
            string CellValue = null;
            int TotalRows = TableRows.Count;
            for (int r = 0; r <= TotalRows; r++)
            {
                if (r + 1 == RowNumber)
                {
                    IList<IWebElement> ColumnsforCurrentRow = TableRows[r].FindElements(ColumnLocator);
                    int TotalColumns = ColumnsforCurrentRow.Count;
                    for (int c = 0; c <= TotalColumns; c++)
                    {
                        if (c + 1 == ColumnNumber)
                        {
                            CellValue = ColumnsforCurrentRow[c].Text;
                        }
                    }
                }
            }
            AppSettings.CoreLogger.Info($"Getting cell value as '{CellValue}' in row number '{RowNumber}' and column number '{ColumnNumber}'");
            return CellValue;
        }


        /// <summary>This method gets the index of any column in web table.</summary>
        /// <param name="HeaderRowColumns">The WebElement for header columns.</param>
        /// <param name="ColumnName">Name of the column.</param>
        /// <returns>The index of the desired column.</returns>
        public static int GetColumnIndex(this IList<IWebElement> HeaderRowColumns, string ColumnName)
        {
            int columnIndex = 0;
            int ColumnCount = HeaderRowColumns.Count;

            for (int c = 0; c < ColumnCount; c++)
            {
                if (HeaderRowColumns[c].Text.Equals(ColumnName.Trim(), StringComparison.OrdinalIgnoreCase))
                {
                    columnIndex = c;
                }
            }
            AppSettings.CoreLogger.Info($"Getting column index value as '{columnIndex}' for column name '{ColumnName}'");
            return columnIndex;
        }

        /// <summary>This method gets all the value of desired column in web table.</summary>
        /// <param name="TableRows">The WebElement for table rows.</param>
        /// <param name="ColumnLocator">The column locator.</param>
        /// <param name="Index">The column index.</param>
        /// <returns>Column values.</returns>
        public static List<string> GetTableColValue(this IList<IWebElement> TableRows, By ColumnLocator, int Index)
        {
            List<string> colValues = new List<string>();
            int rowcount = TableRows.Count;
            for (int r = 0; r < rowcount; r++)
            {
                colValues.Add(TableRows[r].FindElements(ColumnLocator)[Index].Text.ToString());
                AppSettings.CoreLogger.Info($"Getting column value as '{colValues[r]}' for index '{Index}'");
            }
            return colValues;
        }

        /// <summary>
        /// Select Check Box
        /// </summary>
        /// <param name="CheckBox"></param>
        public static void SelectCheckBox(this IWebElement CheckBox, string checkboxName,  bool check= true)
        {
            if(check)
            { 
            if (!CheckBox.Selected)
            {
                CheckBox.Click();
            }
            AppSettings.CoreLogger.Info($"Selecting checkbox '{checkboxName}'");
            }
        }

        /// <summary>
        /// Deselect the selected checkbox
        /// </summary>
        /// <param name="CheckBox"></param>
        public static void DeSelectCheckBox(this IWebElement CheckBox, string checkboxName)
        {
            if (CheckBox.Selected)
            {
                CheckBox.Click();
            }
            AppSettings.CoreLogger.Info($"Unselecting checkbox '{checkboxName}'");
        }

        /// <summary>
        /// GetElement Value By Attribute
        /// </summary>
        /// <param name="WebElement"></param>
        /// <param name="Attribute"></param>
        /// <returns></returns>
        public static string GetElementValueByAttribute(this IWebElement WebElement, string Attribute)
        {
            string value = string.Empty;
            int counter = 0;
            if (Attribute != null)
            {
                do
                {
                    value = WebElement.GetAttribute(Attribute);
                    counter++;
                }
                while (string.IsNullOrEmpty(value) && counter <= 100);
            }
            AppSettings.CoreLogger.Info($"Getting attribute value as '{value}' for attribute '{Attribute}'");
            return value;
        }

        /// <summary>
        /// Setting text and pressing tab key in an element
        /// </summary>
        /// <param name="WebElement"></param>
        /// <param name="Value"></param>
        /// <param name="ElementName"></param>
        public static void SetText(this IWebElement WebElement, string Value, string ElementName)
        {
            try
            { 
            if (!string.IsNullOrWhiteSpace(Value))
                {
                AppSettings.CoreLogger.Info($"Waiting for '{ElementName}' to display");
                BasePage.WaitUntilDisplayed(WebElement, ElementName);
                AppSettings.CoreLogger.Info($"Entering '{Value}' in element '{ElementName}'");                
                    WebElement.Clear();
                    WebElement.SendKeys(Value);
                    WebElement.SendKeys(Keys.Tab);
                }
                    
            }
            catch (Exception ex)
            {
                AppSettings.CoreLogger.Error(ex.Message);
                AppSettings.CoreLogger.Error(ex.StackTrace);
            }
        }

        /// <summary>
        /// Setting text and pressing tab key in an element after switching to frame
        /// </summary>
        /// <param name="WebElement"></param>
        /// <param name="Value"></param>
        /// <param name="ElementName"></param>
        /// <param name="Driver"></param>
        /// <param name="iFrame">iFrame is frame element</param>
        /// <param name="iFrameName">iFrameName is name of iFrame</param>
        public static void SetText(this IWebElement WebElement, string Value, string ElementName, IWebDriver Driver, IWebElement iFrame, string iFrameName)
        {
            try
            {
                if (iFrame != null)
                {
                    Driver.SwitchToFrame(iFrame, iFrameName);
                }

                AppSettings.CoreLogger.Info($"Waiting for '{ElementName}' to display");
                BasePage.WaitUntilDisplayed(WebElement, ElementName);

                AppSettings.CoreLogger.Info($"Entering '{Value}' in element '{ElementName}'");
                if (!string.IsNullOrEmpty(Value)) 
                {
                    WebElement.Clear();
                    WebElement.SendKeys(Value);
                    WebElement.SendKeys(Keys.Tab);
                }
                    

                if (iFrame != null)
                {
                    AppSettings.CoreLogger.Info($"Switching iFrame to Default");
                    Driver.SwitchTo().DefaultContent();
                }
            }
            catch (Exception ex)
            {
                AppSettings.CoreLogger.Error(ex.Message);
                AppSettings.CoreLogger.Error(ex.StackTrace);
            }
        }

        /// <summary>
        /// Setting text in an element after switching to frame
        /// </summary>
        /// <param name="WebElement"></param>
        /// <param name="Value"></param>
        /// <param name="ElementName"></param>
        /// <param name="Driver"></param>
        /// <param name="iFrame">iFrame is frame element</param>
        /// <param name="iFrameName">iFrameName is name of iFrame</param>
        /// <param name="PressEnter">PressEnter parameter is used for pressing enter key after sending text</param>
        public static void SetText(this IWebElement WebElement, string Value, string ElementName, IWebDriver Driver, IWebElement iFrame, string iFrameName, bool PressEnter = false)
        {
            try
            {
                if (iFrame != null)
                {
                    Driver.SwitchToFrame(iFrame, iFrameName);
                }

                AppSettings.CoreLogger.Info($"Waiting for '{ElementName}' to display");
                BasePage.WaitUntilDisplayed(WebElement, ElementName);

                AppSettings.CoreLogger.Info($"Entering '{Value}' in element '{ElementName}'");
                if (!string.IsNullOrEmpty(Value))
                {
                    WebElement.Clear();
                    WebElement.SendKeys(Value);
                }
                    

                if (PressEnter)
                {
                    AppSettings.CoreLogger.Info($"Pressing Enter key");
                    WebElement.SendKeys(Keys.Enter);
                    Driver.WaitForReady();
                }

                if (iFrame != null)
                {
                    AppSettings.CoreLogger.Info($"Switching iFrame to Default");
                    Driver.SwitchTo().DefaultContent();
                }
            }
            catch (Exception ex)
            {
                AppSettings.CoreLogger.Error(ex.Message);
                AppSettings.CoreLogger.Error(ex.StackTrace);
            }
        }

        /// <summary>
        /// Getting text from an element after switching to frame
        /// </summary>
        /// <param name="WebElement"></param>
        /// <param name="ElementName"></param>
        /// <returns></returns>
        public static string GetText(this IWebElement WebElement, string ElementName)
        {
            try
            {
                AppSettings.CoreLogger.Info($"Waiting for '{ElementName}' to display");
                BasePage.WaitUntilDisplayed(WebElement, ElementName);

                var value = WebElement.Text; 
                AppSettings.CoreLogger.Info($"Getting element text as '{value}' from element '{ElementName}'");
                return value;
            }
            catch (Exception ex)
            {
                AppSettings.CoreLogger.Error(ex.Message);
                AppSettings.CoreLogger.Error(ex.StackTrace);
                return null;
            }
        }

        /// <summary>
        /// 
        /// Getting text from an element after switching to frame
        /// </summary>
        /// <param name="WebElement"></param>
        /// <param name="ElementName"></param>
        /// <param name="Driver"></param>
        /// <param name="iFrame">iFrame is frame element</param>
        /// <param name="iFrameName">iFrameName is name of iFrame</param>
        /// <returns></returns>
        public static string GetText(this IWebElement WebElement, string ElementName, IWebDriver Driver, IWebElement iFrame, string iFrameName)
        {
            try
            {
                if (iFrame != null)
                {
                    Driver.SwitchToFrame(iFrame, iFrameName);
                }

                AppSettings.CoreLogger.Info($"Waiting for '{ElementName}' to display");
                BasePage.WaitUntilDisplayed(WebElement, ElementName);

                var value = WebElement.Text;
                AppSettings.CoreLogger.Info($"Getting element text as '{value}' from element '{ElementName}'");


                if (iFrame != null)
                {
                    AppSettings.CoreLogger.Info($"Switching iFrame to Default");
                    Driver.SwitchTo().DefaultContent();
                }

                return value;
            }
            catch (Exception ex)
            {
                AppSettings.CoreLogger.Error(ex.Message);
                AppSettings.CoreLogger.Error(ex.StackTrace);
                return null;
            }
        }

        /// <summary>
        /// 
        /// Clicking on an element
        /// </summary>
        /// <param name="WebElement"></param>
        /// <param name="ElementName"></param>
        /// <param name="Driver"></param>
        public static void ClickElement(this IWebElement WebElement, string ElementName, IWebDriver Driver)
        {
            try
            {
                AppSettings.CoreLogger.Info($"Waiting for '{ElementName}' to display");
                Driver.WaitForClickable(WebElement, ElementName);
                var elementText = WebElement.Text;
                if(string.IsNullOrEmpty(elementText))
                    elementText=WebElement.GetAttribute("value");
                AppSettings.CoreLogger.Info($"Clicking on element '{ElementName}' having text '{elementText}'");
                WebElement.Click();
                Driver.WaitForReady();
            }
            catch (Exception ex)
            {
                AppSettings.CoreLogger.Error(ex.Message);
                AppSettings.CoreLogger.Error(ex.StackTrace);
            }
        }

        /// <summary>
        /// Clicking on an element after switching to frame
        /// </summary>
        /// <param name="WebElement"></param>
        /// <param name="ElementName"></param>
        /// <param name="Driver"></param>
        /// <param name="iFrame">iFrame is frame element</param>
        /// <param name="iFrameName">iFrameName is name of iFrame</param>
        public static void ClickElement(this IWebElement WebElement, string ElementName, IWebDriver Driver, IWebElement iFrame, string iFrameName)
        {
            try
            {
                if (iFrame != null)
                {
                    Driver.SwitchToFrame(iFrame, iFrameName);
                }

                AppSettings.CoreLogger.Info($"Waiting for '{ElementName}' to display");
                Driver.WaitForClickable(WebElement, ElementName);

                AppSettings.CoreLogger.Info($"Clicking on element '{ElementName}'");
                WebElement.Click();
                Driver.WaitForReady();

                if (iFrame != null)
                {
                    AppSettings.CoreLogger.Info($"Switching iFrame to Default");
                    Driver.SwitchTo().DefaultContent();
                }
            }
            catch (Exception ex)
            {
                AppSettings.CoreLogger.Error(ex.Message);
                AppSettings.CoreLogger.Error(ex.StackTrace);
            }
        }
    }
}
