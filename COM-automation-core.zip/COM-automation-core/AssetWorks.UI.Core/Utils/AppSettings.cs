﻿using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.Core.Utils
{
    /// <summary>
    /// AppSetting variables
    /// </summary>
    internal static class AppSettings
    {
        public static bool RemoteFlag { get; set; } = false;
        public static bool HeadlessFlag { get; set; } = false;
        public static bool Windows10 { get; set; } = true;
        public static int WaitTime { get; set; }
        public static string PlatformName { get; set; } = String.Empty;
        public static string Platform { get; set; }
        public static string HubUrl { get; set; }
        public static bool ExtentReport { get; set; }
        public static bool TestRailReport { get; set; }
        public static string ApiBaseUrl { get; set; }
        public static string ApiUsername { get; set; }
        public static string ApiPassword { get; set; }
        public static string ApiEndPoint { get; set; }
        public static int ApiProjectId { get; set; }
        public static int ApiMilestoneId { get; set; }
        public static bool Logs { get; set; }
        public static ILog CoreLogger { get; set; }

        public static string QueryPath = AppDomain.CurrentDomain.BaseDirectory + "TestData\\DataTableQuery.json";
    }
}
