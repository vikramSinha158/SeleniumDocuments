﻿using AssetWorks.UI.Core.Extensions;
using AventStack.ExtentReports;
using log4net;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using OpenQA.Selenium;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;

namespace AssetWorks.UI.Core.Utils
{
    /// <summary>
    /// CommonUtils class contains all common utilities methods
    /// </summary>
    public class CommonUtils
    {
        private static readonly Random _random = new Random();
        /// <summary>This variable is used for storing config.</summary>
        private Dictionary<string, string> _config;
        readonly FlatFile FlatFileReading = new FlatFile();
        /// <summary>
        /// It will be used to pass a delimiter from user end with file loading method.
        /// </summary>
        public char UserDelimeter { get; set; }

        /// <summary>This method gets the configuration from configuration file.</summary>
        /// <param name="Path">The path where config files are created.</param>
        /// <returns>Configuration values.</returns>
        public static IConfigurationRoot GetConfig(string Path)
        {
            var configuration = new ConfigurationBuilder()
                 .AddJsonFile(Path)
                 .Build();
            return configuration;
        }

        /// <summary>This method is used for return random string with requested size in lower or upper case.</summary>
        /// <param name="Size">Size of the generated string.</param>
        /// <param name="LowerCase">True if you want to generate the string in lowercase,otherwise false.</param>
        /// <returns>Any random string of desired length and case. </returns>
        public static string RandomString(int Size, bool LowerCase)
        {
            if (Size == 0) return null;
            StringBuilder builder = new StringBuilder();
            char ch;
            for (int i = 0; i < Size; i++)
            {
                ch = Convert.ToChar(Convert.ToInt32(Math.Floor(26 * _random.NextDouble() + 65)));
                builder.Append(ch);
            }
            if (LowerCase)
                return builder.ToString().ToLower();

            AppSettings.CoreLogger.Info($"Getting random string value as '{builder.ToString()}'");
            return builder.ToString();
        }

        /// <summary>
        /// Method to load files of any type like Json, .txt, .properties, .config.
        /// </summary>
        /// <param name="DataFilePath">Path where file resides. </param>
        /// <param name="UserDelimeter">Delimiter provided by User.</param>
        /// <returns>File contents in dictionary format. </returns>
        public Dictionary<string, string> LoadFiles(string DataFilePath, char UserDelimeter)
        {
            string Extension = Path.GetExtension(DataFilePath);
            if (Extension.Contains(".json"))
            {
                _config = FlatFileReading.JsonFileRead(DataFilePath);
            }
            else
            {
                _config = FlatFileReading.ReadFile(DataFilePath, UserDelimeter);
            }
            return _config;
        }

        /// <summary>This method takes the screenshot.</summary>
        /// <param name="Driver">The selenium driver instance.</param>
        /// <param name="Path">The path where screenshot are to be captured.</param>
        /// <returns>The path of screenshots location.</returns>
        public static MediaEntityModelProvider TakeScreenshot(IWebDriver Driver, string Path)
        {
            int min = 1000;
            int max = 99999999;
            Random rdm = new Random();
            string pathScreen = Path + "\\" + DateTime.Now.ToString("dd_MM_yyyy_hh_mm_ss_tt") + "_" + rdm.Next(min, max) + ".png";
            Screenshot screenshot = ((ITakesScreenshot)Driver).GetScreenshot();
            screenshot.SaveAsFile(pathScreen, ScreenshotImageFormat.Png);
            var screenShetAs = screenshot.AsBase64EncodedString;

            return MediaEntityBuilder.CreateScreenCaptureFromBase64String(screenShetAs, "Failed").Build();
        }

        /// <summary>This method creates the folder with time stamp.</summary>
        /// <param name="Path">The path where this folder is to be created.</param>
        /// <param name="FolderName">The string which you would like start your folder name with.</param>
        /// <returns>The path of the created folder.</returns>
        public static string CreateFolder(string Path, string FolderName)
        {
            string folderName = FolderName + DateTime.Now.ToString("dd_MM_yyyy_hh_mm_ss_tt");
            if (!Directory.Exists(Path + folderName))
            {
                Directory.CreateDirectory(Path + folderName);
            }
            AppSettings.CoreLogger.Info($"Creating folder at '{Path + folderName}'");
            return Path + folderName;
        }


        /// <summary>
        /// check eqaulty of two list
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="List"></param>
        /// <param name="Otherlist"></param>
        /// <returns>Return the bool value whether two list are equal or not</returns>
        public bool CompareList<T>(List<T> List, List<T> Otherlist) where T : IEquatable<T>
        {
            if (List.Except(Otherlist).Any())
                return false;
            if (Otherlist.Except(List).Any())
                return false;
            return true;
        }

        /// <summary>
        /// check contain of second list in first list
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="List1"></param>
        /// <param name="OtherList"></param>
        /// <returns>return the bool to check contain of second list in first list</returns>
        public bool CheckContainList<T>(List<T> List1, List<T> OtherList) where T : IEquatable<T>
        {
            if (List1.Intersect(OtherList).Any())
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Compare two integer number
        /// </summary>
        /// <param name="Int1"></param>
        /// <param name="Int2"></param>
        /// <returns>Return bool after comperison two integer</returns>
        public bool CompareInteger(int Int1, int Int2)
        {
            if (Int1 == Int2)
                return true;
            else
                return false;
        }

        /// <summary>
        /// Genrating a random integer/long value
        /// </summary>
        /// <param name="MinValue"></param>
        /// <param name="MaxValue"></param>
        /// <returns></returns>
        public long GenerateRandomIntValue(int MinValue = 1000, int MaxValue = 99999999)
        {
            Random rdm = new Random();
            var value = (long)rdm.Next(MinValue, MaxValue);
            AppSettings.CoreLogger.Info($"Getting random Integer value {value}");
            return value;
        }

        /// <summary>
        /// Genrating a random double/decimal value
        /// </summary>
        /// <param name="MinValue"></param>
        /// <param name="MaxValue"></param>
        /// <returns></returns>
        public double GenerateRandomDecimalNumber(int MinValue = 1000, int MaxValue = 99999999)
        {
            Random rdm = new Random();
            var value = (double)rdm.Next(MinValue, MaxValue) / 100;
            AppSettings.CoreLogger.Info($"Getting random Integer value {value}");
            return value;
        }

        /// <summary>
        /// Compare Drop Down
        /// </summary>
        /// <param name="List"></param>
        /// <param name="Dropdown"></param>
        /// <returns>Return bool value</returns>
        public bool CompareDropDown(List<string> table, IWebElement Dropdown)
        {
            var uiDropDownValues = Dropdown.GetDropdownValueList();
            uiDropDownValues.RemoveAt(0);
            return CompareList(table, uiDropDownValues);
        }

        /// <summary>
        /// Get Solution Path
        /// </summary>
        /// <returns>string</returns>
        public string? SolutionPath()
        {
            var folderName = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
            if (folderName != null)
            {
                return folderName.Substring(0, folderName.LastIndexOf("\\bin"));
            }
            return null;

        }

        /// <summary>This method gets the folder path.</summary>
        /// <param name="AppFolderName">Name of the application folder.</param>
        /// <returns>The path of the required folder.</returns>
        public string GetFolderPath(string AppFolderName)
        {
            var folderName = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
            if (folderName == null) { folderName = AppDomain.CurrentDomain.BaseDirectory; }
            return Path.Combine(folderName.Substring(0, folderName.LastIndexOf("\\bin")), AppFolderName + "\\");
        }

        /// <summary>This method Loads the json.</summary>
        /// <param name="TestDataPath">The test data file path.</param>
        /// <returns>Json Object.</returns>
        public string LoadJson(string TestDataPath)
        {
            using (StreamReader r = new StreamReader(TestDataPath))
            {
                var json = r.ReadToEnd();
                return JObject.Parse(json).ToString();

            }
        }

        /// <summary>
        /// Remove Time From Date
        /// </summary>
        /// <param name="DateWithTime"></param>
        /// <returns>string</returns>
        public string RemoveTimeFromDate(string DateWithTime)
        {
            DateTime oDate = DateTime.Parse(DateWithTime);
            return oDate.ToShortDateString();
        }

        /// <summary>
        /// Split String
        /// </summary>
        /// <param name="Input"></param>
        /// <param name="SplitType"></param>
        /// <returns>String[]</returns>
        public String[]? SplitString(string Input, string SplitType)
        {
            switch (SplitType)
            {
                case "Pipe":
                    return Input.Split("|");
                case "NewLine":
                    return Input.Split(new string[] { "\r\n", "\n" }, StringSplitOptions.None);
                case ":":
                    return Input.Split(":");
                case "Comma":
                    return Input.Split(",");
                case " ":
                    return Input.Split(" ");
                case "-":
                    return Input.Split("-");
                case "=":
                    return Input.Split("=");
            }
            return null;

        }

        /// <summary>
        /// Genrate random date in MM/DD/YYYY format 
        /// </summary>
        /// <returns> Random date </returns>
        public string GenerateRandomDateString(int days)
        {
            DateTime thisDay = DateTime.Today;
            var value = thisDay.AddDays(days).Date.ToString("MM/dd/yyyy");
            AppSettings.CoreLogger.Info($"Getting random date string '{value}'");
            return value;
        }

        /// <summary>
        /// Genrate random date in MM/DD/YYYY format 
        /// </summary>
        /// <param name="Date"></param>
        /// <param name="Days"></param>
        /// <returns></returns>
        public string GenerateRandomDateString(string Date, int Days)
        {
            DateTime givenDate = DateTime.Parse(Date);
            var value = givenDate.AddDays(Days).Date.ToString("MM/dd/yyyy");
            AppSettings.CoreLogger.Info($"Getting random date string '{value}'");
            return value;
        }

        /// <summary>
        /// Genrate future date in "MM/dd/YYYY HH:mm" format 
        /// </summary>
        /// <param name="Days"></param>
        /// <returns></returns>
        public string GenerateFutureDateAndTimeString(int days)
        {
            DateTime thisDay = DateTime.Today;
            var value = thisDay.AddDays(days).Date.ToString("MM/dd/yyyy HH:mm");
            AppSettings.CoreLogger.Info($"Getting random date string '{value}'");
            return value;
        }

        /// <summary>
        /// Generates a random alphanumeric number based on the input length
        /// </summary>
        /// <returns></returns>
        public String GetRandomStringWithSpecialChars(int length = 10, bool alphaNumeric = true, bool specialChars = false)
        {
            Random random = new Random();

            string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

            if (alphaNumeric)
                chars = chars + "0123456789";

            if (specialChars)
                chars = chars + @"`~!@#$%^&*()-_=+[{]}\|;:',<.>/?";

            var value = new string(Enumerable.Repeat(chars, length)
              .Select(s => s[random.Next(s.Length)]).ToArray());

            AppSettings.CoreLogger.Info($"Getting random string '{value}'");

            return value;
        }

        /// <summary>
		/// GetRendom Value From Liist
		/// </summary>
		/// <param name="Datalist"></param>
		/// <param name="dataIndex"></param>
		/// <returns></returns>
		public String GetRandomValueFromList(List<String> Datalist)
        {
            Random random = new Random();
            int dataIndex = random.Next(Datalist.Count);
            var value = Datalist[dataIndex].ToString();
            AppSettings.CoreLogger.Info($"Getting random value from list '{value}'");
            return value;
        }

        /// <summary>
        /// Load data for test
        /// </summary>
        /// <param name="Filename"></param>
        /// <param name="VerificationKey"></param>
        public void LoadTestData(string Filename, string VerificationKey)
        {
            TestDataReader.LoadTestDataFromJson(Filename, VerificationKey);
        }

        /// <summary>
        /// Get test data value for key
        /// </summary>
        /// <param name="Key"></param>
        /// <returns></returns>
        public string DataForKey(string Key)
        {
            return TestDataReader.GetTestdataValueByDataKey(Key);
        }

        /// <summary>
        /// Get test data value from data object for key
        /// </summary>
        /// <param name="Key"></param>
        /// <param name="DataObject"></param>
        /// <returns></returns>
        public string DataForKey(string Key, JObject DataObject)
        {
            return TestDataReader.GetTestdataFromObjectBykey(Key, DataObject);
        }

        /// <summary>
        /// Get test data object for key
        /// </summary>
        /// <param name="Key"></param>
        /// <returns></returns>
        public dynamic DataObjectForKey(string Key)
        {
            return TestDataReader.GetTestdataObjectByDataKey(Key);
        }

        /// <summary>
        /// Getting description from enum value
        /// </summary>
        /// <param name="EnumValue"></param>
        /// <returns></returns>
        public string GetEnumDescription(Enum EnumValue)
        {
            var fieldInfo = EnumValue.GetType().GetField(EnumValue.ToString());
            var descriptionAttributes = (System.ComponentModel.DescriptionAttribute[])fieldInfo.GetCustomAttributes(typeof(System.ComponentModel.DescriptionAttribute), false);
            var desc = descriptionAttributes.Length > 0 ? descriptionAttributes[0].Description : EnumValue.ToString();
            return desc;
        }

        /// <summary>
        /// Common assertion to compare value
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="ExpectedValue">Expected value</param>
        /// <param name="ActualValue">Actual value</param>
        public void AssertTrue<T>(T ExpectedValue, T ActualValue)
        {
            try
            {
                Assert.True(ExpectedValue.Equals(ActualValue), $"'{ExpectedValue}' expected value matched with actual value '{ActualValue}'");
                AppSettings.CoreLogger.Info($"Expected value : {ExpectedValue} matched with Actual value : {ActualValue}");
            }
            catch (Exception ex)
            {
                AppSettings.CoreLogger.Error($"Expected value : {ExpectedValue} not matched with actual value : {ActualValue}");
                Assert.Fail($"'{ExpectedValue}' expected value not matched with actual value '{ActualValue}'");
            }
        }

        ///<summary>
        /// the method for TestCase Status
        ///</summary>
        ///<typeparam name="QANumber">QANumber</typeparam>
        static IList<string> passedTestCases = new List<string>();
        public void AddPassedTestCase(string QANumber)
        {
            passedTestCases.Add(QANumber);
            AppSettings.CoreLogger.Info($" ----------------{QANumber}: The Test Case is Passed----------------");
        }

        public void VerifyPassedTestCase(string QANumber)
        {
            AssertTrue(true, passedTestCases.Contains(QANumber));
        }

        /// <summary>
        /// Set Test Data for current test.
        /// </summary>
        /// <param name="Arguments">TestContext.CurrentContext.Test.Arguments.GetValue(0)</param>
        /// <exception cref="System.Exception"></exception>
        public void SetTestData(object Arguments)
        {
            if (Arguments != null)
            {
                List<string> _params = JsonConvert.DeserializeObject<List<string>>(JsonConvert.SerializeObject(Arguments));
                string _fileName = _params[0];
                string _verificationKey = _params[1];
                if (_fileName != null && _verificationKey != null)
                    LoadTestData(_fileName, _verificationKey);
                else
                    throw new System.Exception("Test data file or data key not found.!");
            }
        }

        /// <summary>
        /// Verify Element Value
        /// </summary>
        /// <param name="Element"></param>
        /// <param name="Elementname"></param>
        /// <param name="ExpectedValue"></param>
        /// <param name="DropDown"></param>
        /// <param name="AttributeValue"></param>
         public void VerifyElementValue(IWebElement Element, string Elementname, string ExpectedValue, bool DropDown = false, string AttributeValue = "ovalue")
        {
            string empty = string.Empty;
            if (!string.IsNullOrEmpty(ExpectedValue))
            {
                AppSettings.CoreLogger.Info("Verifying Actual and Expected Values for " + Elementname);
                empty = ((!DropDown) ? Element.GetElementValueByAttribute(AttributeValue) : Element.GetVisibleText());
                AssertTrue(ExpectedValue, empty);
            }
        }

        /// <summary>
        /// Verify Checkbox State
        /// </summary>
        /// <param name="Element"></param>
        /// <param name="ElementName"></param>
        /// <param name="Selected"></param>
        public void VerifyCheckboxState(IWebElement Element, string ElementName, bool Selected)
        {
            AppSettings.CoreLogger.Info("Verifying Checked Status for Checkbox " + ElementName);
            bool flag = false;
            flag = Element.Selected;
            ILog coreLogger = AppSettings.CoreLogger;
            DefaultInterpolatedStringHandler defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(29, 2);
            defaultInterpolatedStringHandler.AppendLiteral("Actual Checked State for ");
            defaultInterpolatedStringHandler.AppendFormatted(ElementName);
            defaultInterpolatedStringHandler.AppendLiteral(" is ");
            defaultInterpolatedStringHandler.AppendFormatted(flag);
            coreLogger.Info(defaultInterpolatedStringHandler.ToStringAndClear());
            AssertTrue(Selected, flag);
        }

        /// <summary>
        /// VerifyElementValueNotBlank
        /// </summary>
        /// <param name="Element"></param>
        /// <param name="ElementName"></param>
        /// <param name="FlagToVerify"></param>
        /// <param name="AttributeValue"></param>
        public void VerifyElementValueNotBlank(IWebElement Element, string ElementName, bool FlagToVerify = false, string AttributeValue = "ovalue")
        {
            if (FlagToVerify)
            {
                ILog coreLogger = AppSettings.CoreLogger;
                DefaultInterpolatedStringHandler defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(48, 2);
                defaultInterpolatedStringHandler.AppendLiteral("Verifying Attritube Value [");
                defaultInterpolatedStringHandler.AppendFormatted(AttributeValue);
                defaultInterpolatedStringHandler.AppendLiteral("] for [");
                defaultInterpolatedStringHandler.AppendFormatted(ElementName);
                defaultInterpolatedStringHandler.AppendLiteral("] is Not Blank");
                coreLogger.Info(defaultInterpolatedStringHandler.ToStringAndClear());
                string elementValueByAttribute = Element.GetElementValueByAttribute(AttributeValue);
                Assert.IsFalse(string.IsNullOrEmpty(elementValueByAttribute), " " + ElementName + " Value is Blank");
            }
        }
            
        /// <summary>
        /// Createing Connection for Oracle Or SQL
        /// </summary>
        /// <param name="ConnectingString"></param>
        /// <param name="DBType"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public static DbConnection CreateConnection(string ConnectingString, string DBType)
        {
             DbConnection Connection = null;
            if (DBType.ToUpper().Contains("ORACLE"))
                Connection = new OracleConnection(ConnectingString);
            else
                Connection = new SqlConnection(ConnectingString);
            try
            {
                Connection.Open();
                AppSettings.CoreLogger.Info($"Connecting to the {DBType}");
            }
            catch(Exception e)
            {
                AppSettings.CoreLogger.Info($"Connection is not Created for {DBType}, {Connection}");
                throw new Exception($"Connection is not Established {e}");
            }
            return Connection;
        }
        /// <summary>
        /// Checking the Data is exisit or not and returning the boolean
        /// </summary>
        /// <param name="con"></param>
        /// <param name="Key"></param>
        /// <param name="Params"></param>
        /// <param name="DBType"></param>
        /// <returns></returns>
        public bool CheckDataExist(DbConnection con, string Key, string Params, string DBType)
        {
            FlatFile file = new FlatFile();
            string Query = null;
            file.JsonFileRead(AppSettings.QueryPath).TryGetValue(Key, out Query);

            string p1 = String.Concat("'", Params, "'");
            string FinalQuery = string.Format(Query, p1);

            DbCommand cmd = null;
            if (DBType.ToUpper().Contains("ORACLE"))
                cmd = new OracleCommand(FinalQuery, (OracleConnection)con);
            else if (DBType.ToUpper().Contains("SQL"))
                cmd = new SqlCommand(FinalQuery, (SqlConnection)con);

            string queryResult = Convert.ToString(cmd.ExecuteScalar());
            AppSettings.CoreLogger.Info($"Verifying Data is present or not for the Query {Query}");
            return (!string.IsNullOrEmpty(queryResult));
        }

        /// <summary>
        ///  Method to Fetch the Data Table for the Query
        /// </summary>
        /// <param name="Con"></param>
        /// <param name="Key"></param>
        /// <param name="DBType"></param>
        /// <returns></returns>
        public DataTable GetDataFromTable(DbConnection Con, string Key, string DBType)
        {
            FlatFile file = new FlatFile();
            string Query = null;
            file.JsonFileRead(AppSettings.QueryPath).TryGetValue(Key, out Query);
            DataTable tab = new DataTable();
            OracleDataAdapter OracledataAdapter = null;
            SqlDataAdapter sqlDataAdapter = null;
            if (DBType.ToUpper().Contains("ORACLE"))
            {
                OracledataAdapter = new OracleDataAdapter(Query, (OracleConnection)Con);
                OracledataAdapter.Fill(tab);
            }
            else if (DBType.ToUpper().Contains("SQL"))
            {
                sqlDataAdapter = new SqlDataAdapter(Query, (SqlConnection)Con);
                sqlDataAdapter.Fill(tab);
            }
            else
                throw new Exception("No DB Connection is available for the Given DB Type");

            AppSettings.CoreLogger.Info($"Reading Data in Table Format for the Query {Query}");
            return tab;
        }

        /// <summary>
        /// Method to execute Query that returns nothing Insert/Delete Query
        /// </summary>
        /// <param name="con"></param>
        /// <param name="Key"></param>
        /// <param name="DBType"></param>
        public void ExecuteQuery(DbConnection con, string Key, string DBType)
        {
            FlatFile file = new FlatFile();
            string Query = null;
            file.JsonFileRead(AppSettings.QueryPath).TryGetValue(Key, out Query);
            DbCommand cmd = null;
            if (DBType.ToUpper().Contains("ORACLE"))
                cmd = new OracleCommand(Query, (OracleConnection)con);
            else if (DBType.ToUpper().Contains("SQL"))
                cmd = new SqlCommand(Query, (SqlConnection)con);
            else
                throw new Exception("No DB Connection is available for the Given DB Type");
            AppSettings.CoreLogger.Info($"Executing the Query {Query}");
            cmd.ExecuteReader();
        }
        /// <summary>
        /// Method to Close the Created DB Connection
        /// </summary>
        /// <param name="con"></param>
        /// <param name="Key"></param>
        /// <param name="DBType"></param>
        /// <returns></returns>
        public string ReturnFirstValue(DbConnection con, string Key, string DBType)
        {
            FlatFile file = new FlatFile();
            string Query = null;
            file.JsonFileRead(AppSettings.QueryPath).TryGetValue(Key, out Query);
            DbCommand cmd = null;
            if (DBType.ToUpper().Contains("ORACLE"))
                cmd = new OracleCommand(Query, (OracleConnection)con);
            else if (DBType.ToUpper().Contains("SQL"))
                cmd = new SqlCommand(Query, (SqlConnection)con);
            else
                throw new Exception("No DB Connection is available for the Given DB Type");

            string queryResult = Convert.ToString(cmd.ExecuteScalar());
            AppSettings.CoreLogger.Info($"Executing and returing the first record for the Query {Query}");
            return queryResult;
        }

        public static void CloseConnection(DbConnection con)
        {
            if (con != null)
                con.Close();
        }
    }
}
