﻿using AssetWorks.UI.Core.Base;
using AssetWorks.UI.Core.Integrations;
using log4net;
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace AssetWorks.UI.Core.Utils
{
    /// <summary>
    /// Initilize driver instance according to driver type and browser type
    /// </summary>
    public class TestInitializeHooks
    {
        public IWebDriver? Driver;
        protected BasePage CurrentPage;
        private DriverFactory _driverFactory = new DriverFactory();
        private TestRail _testRail = new TestRail();
        List<TestResults> TestResults = new List<TestResults>();
        private AppConfigReader _appReader = new AppConfigReader();

        public CommonUtils CommonUtil = new CommonUtils();

        public TestInitializeHooks() { }

        public TestInitializeHooks(IWebDriver? Driver)
        {
            this.Driver = Driver;
        }

        /// <summary>
        /// Load Core Data Setting
        /// </summary>
        /// <param name="AppPath"></param>
        public void LoadCoreDataSetting(string AppPath)
        {
            AppConfigReader.AppSettingPath = AppPath;
            _appReader.LoadSettings();
        }

        /// <summary>
        /// Initializing Core Logger instance
        /// </summary>
        /// <param name="Logger"></param>
        public void InitializeCoreLogger(ILog Logger)
        {
            AppSettings.CoreLogger = Logger;
        }

        /// <summary>
        /// Initialzing driver
        /// </summary>
        public void InitializeDriver(string BrowserName)
        {
            Driver = _driverFactory.InitDriver(BrowserName);
            Driver.Manage().Window.Maximize();
            AppSettings.CoreLogger.Info("Browser window maximized");
        }

        /// <summary>
        /// Initialize Test rail Client
        /// </summary>
        /// <returns></returns>
        public int InitializeTestrailClient()
        {
            if (AppSettings.TestRailReport)
            {

                AppSettings.CoreLogger.Info($"Initializing Test Rail report");
                int runId = _testRail.AddRunAndGetRunId();
                return runId;
            }
            return 0;
        }

        /// <summary>
        /// Naviate url
        /// </summary>
        public virtual void NavigateSite(string AutUrl, int ImpllicitWt)
        {
            AppSettings.CoreLogger.Info($"Navigating to app url '{AutUrl}'");
            Driver.Navigate().GoToUrl(AutUrl);
            Driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(ImpllicitWt);
        }

        /// <summary>
        /// Close all browser nad driver
        /// </summary>
        public void CloseBrowser()
        {
            AppSettings.CoreLogger.Info($"Closing browser");
            Driver.Quit();
            Driver.Dispose();
        }

        /// <summary>
        /// updateCurrentTestResult : update current test results
        /// </summary>
        /// <param name="TestContext"></param>
        /// <returns> list of test results</returns>
        public List<TestResults>? UpdateCurrentTestResult(TestContext TestContext)
        {
            if (AppSettings.TestRailReport)
            {
                AppSettings.CoreLogger.Info($"Updating Test Rail results in report");
                if (TestContext != null)
                {
                    var currentTestName = TestContext.Test.Name;
                    var testResult = TestContext.Result.Outcome.Status.ToString();
                    if (testResult == "Failed")
                    {
                        string testError = TestContext.Result.Message;
                        TestResults.Add(new TestResults(currentTestName, testResult, testError));
                    }
                    else
                        TestResults.Add(new TestResults(currentTestName, testResult, ""));
                }
                else
                    Console.WriteLine("Test result not found for current test.");

                return TestResults;
            }
            return null;
        }

        /// <summary>
        /// Creating connection to DB based on DB Type
        /// </summary>
        /// <param name="OracleConnectinString"></param>
        /// <param name="SQlConnectionString"></param>
        /// <param name="DBType"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public DbConnection GetDBConnection(string OracleConnectinString,string SQlConnectionString,string DBType)
        {
            DbConnection connection=null;
            if (DBType.ToUpper().Contains("ORACLE"))
                connection = CommonUtils.CreateConnection(OracleConnectinString, DBType);
            else if (DBType.ToUpper().Contains("SQL"))
                connection = CommonUtils.CreateConnection(SQlConnectionString, DBType);
            else
                throw new Exception("No DB Connection is available for the Given DB Type");
            return connection;
        }

        /// <summary>
        /// It's important to kill all processes before attempting to replace the chrome driver, because if you do not you may still have file locks left over
        /// </summary>
        public void KillChromeProcess()
        {
            var processes = Process.GetProcessesByName("chromedriver");
            foreach (var process in processes)
            {
                try
                {
                    process.Kill();
                }
                catch
                {
                }
            }
        }

        /// <summary>
        /// Install the chrome Driver as per installed version  
        /// </summary>
        /// <returns></returns>
        public async Task AutoUpdateChromeDriver()
        {
            KillChromeProcess();
            var chromeDriverInstaller = new ChromeDriverInstaller();
            var chromeVersion = await chromeDriverInstaller.GetChromeVersion();
            await chromeDriverInstaller.Install(chromeVersion);
        }
    }
}
