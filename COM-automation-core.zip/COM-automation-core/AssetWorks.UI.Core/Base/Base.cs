﻿using AssetWorks.UI.Core.Utils;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetWorks.UI.Core.Base
{
    /// <summary>
    /// Base class
    /// </summary>
    public class Base
    {
        protected IWebDriver? Driver;
        protected BasePage CurrentPage;

        public Base() { }

        public Base(IWebDriver Driver)
        {
            this.Driver = Driver;
        }

        /// <summary>
        /// Generic method to create instance of class
        /// </summary>
        /// <typeparam name="TPage"></typeparam>
        /// <returns>Return the instence for current class</returns>
        public TPage As<TPage>() where TPage : BasePage
        {
            return (TPage)this;
        }

        /// <summary>
        /// Created object for common util
        /// </summary>
        public CommonUtils CommonUtil = new CommonUtils();
    }
}
